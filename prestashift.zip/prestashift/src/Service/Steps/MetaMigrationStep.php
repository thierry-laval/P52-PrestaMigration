<?php
/**
 * PrestaShift Migration Module
 *
 * @author    marcingajewski.pl <kontakt@marcingajewski.pl>
 * @copyright 2026 marcingajewski.pl
 * Modifié par : Thierry Laval <contact@thierrylaval.dev>
 * @copyright 2026 Thierry Laval
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License 3.0 (AFL-3.0)
 * @attribution PrestaShift by Marcin Gajewski (marcingajewski.pl). Keep the Attribution Notice in prestashift.php — AFL-3.0 section 6.
 * @version   1.3.0
 */
namespace PrestaShift\Service\Steps;

use Db;
use PDO;
use PrestaShift\Service\IdMapper;
use PrestaShift\Service\LanguageMapper;
use PrestaShift\Service\SchemaHelper;
use PrestaShift\Service\SourceBatch;

/**
 * SEO meta of shop pages. The page name is unique: a page the target already
 * has keeps its record. Its titles and friendly URLs are replaced by the
 * source's only when "Clean target data" was chosen (the source wins);
 * otherwise the target's own texts stay. Pages the target does not have are
 * added.
 */
class MetaMigrationStep
{
    private $db_connection;
    private $prefix;

    /** @var array source id_meta => translation rows, read once per batch */
    private $langRows = [];

    public function __construct($db_connection, $prefix)
    {
        $this->db_connection = $db_connection;
        $this->prefix = $prefix;
    }

    public function process($offset, $limit, $dateFilter = null)
    {
        if ($offset != 0) {
            return ['count' => 0, 'finished' => true];
        }

        $items = $this->db_connection->query("SELECT * FROM `{$this->prefix}meta` ORDER BY id_meta ASC")->fetchAll(PDO::FETCH_ASSOC);

        $overwrite = (bool)IdMapper::option('clean_target');

        // All meta titles in one query instead of one query per page
        $this->langRows = SourceBatch::grouped($this->db_connection,
            "SELECT * FROM `{$this->prefix}meta_lang` WHERE id_meta IN ({ids}) ORDER BY id_shop ASC",
            'id_meta', array_column($items, 'id_meta'));

        foreach ($items as $data) {
            $sid = (int)$data['id_meta'];
            $tid = IdMapper::own('meta', $sid, ['page' => $data['page']]);
            $linked = IdMapper::isLinked('meta', $sid);

            if ($linked && !$overwrite) {
                continue;
            }
            if (!$linked) {
                $data['id_meta'] = $tid;
                SchemaHelper::upsert('meta', $data, ['id_meta']);
            }

            $this->importMetaLang($sid, $tid);
        }

        return ['count' => count($items), 'finished' => true];
    }

    private function importMetaLang($sid, $tid)
    {
        $shopId = SchemaHelper::getTargetShopId();
        $rows = LanguageMapper::expand(SourceBatch::of($this->langRows, $sid));

        $done = [];
        foreach ($rows as $lang) {
            if (isset($done[(int)$lang['id_lang']])) {
                continue;
            }
            $done[(int)$lang['id_lang']] = true;
            $lang['id_meta'] = $tid;
            $lang['id_shop'] = $shopId;
            SchemaHelper::upsert('meta_lang', $lang, ['id_meta', 'id_shop', 'id_lang']);
        }
    }
}
